//{{AFX_INCLUDES()
#include "resource.h"

#include "dsspanel.h"
#include "plabel.h"

//}}AFX_INCLUDES
#if !defined(AFX_DIALOGTENKEY_H__BE99CD60_BC1C_4752_8B53_CDA63B983477__INCLUDED_)
#define AFX_DIALOGTENKEY_H__BE99CD60_BC1C_4752_8B53_CDA63B983477__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogTenkey.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogTenkey dialog

class CDialogTenkey : public CDialog
{
// Construction
public:
	CDialogTenkey(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDialogTenkey();
	int m_nTenKeyNumber;
	void DispComment();
	void CommentSet(double dMin, double dMax, CString str);
	void InitControl();
	void CommentSet(double dMin, double dMax, CString str, int nX, int nY);
	BOOL PreTranslateMessage(MSG* pMsg);
// Dialog Data
	//{{AFX_DATA(CDialogTenkey)
	enum { IDD = IDD_DIALOG_TENKEY_PAD};
	CString			m_strTenKeyDisplay;
	//CDSSPanel		m_ctrlMinValue;
	//CDSSPanel		m_ctrlMaxValue;
	CPLabel	m_ctrlComment;
	//}}AFX_DATA
	int nSrtX,nSrtY;
	double m_dMin, m_dMax;
	CString m_strComment;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogTenkey)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogTenkey)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickCancel2();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void MouseUpNum0(short Button, short Shift, long x, long y);
	void MouseUpNum1(short Button, short Shift, long x, long y);
	void MouseUpNum2(short Button, short Shift, long x, long y);
	void MouseUpNum3(short Button, short Shift, long x, long y);
	void MouseUpNum4(short Button, short Shift, long x, long y);
	void MouseUpNum5(short Button, short Shift, long x, long y);
	void MouseUpNum6(short Button, short Shift, long x, long y);
	void MouseUpNum7(short Button, short Shift, long x, long y);
	void MouseUpNum8(short Button, short Shift, long x, long y);
	void MouseUpNum9(short Button, short Shift, long x, long y);
	void MouseUpNumDot(short Button, short Shift, long x, long y);
	void MouseUpNumMinus(short Button, short Shift, long x, long y);
	void MouseUpNumberBack(short Button, short Shift, long x, long y);
	void MouseUpNumberClr(short Button, short Shift, long x, long y);
	void MouseUpNumberEnt(short Button, short Shift, long x, long y);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGTENKEY_H__BE99CD60_BC1C_4752_8B53_CDA63B983477__INCLUDED_)
