
// DatabaseLibDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "DatabaseLib.h"
#include "DatabaseLibDlg.h"
#include "afxdialogex.h"

#include "User.h"
#include "Database.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

// �����Դϴ�.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
	EnableActiveAccessibility();
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CDatabaseLibDlg ��ȭ ����



CDatabaseLibDlg::CDatabaseLibDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDatabaseLibDlg::IDD, pParent)
{
	EnableActiveAccessibility();
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDatabaseLibDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_USER, m_ctrl_user_list);
	DDX_Control(pDX, IDC_CHECK_ALL, m_ctrl_checkAll);
}

BEGIN_MESSAGE_MAP(CDatabaseLibDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ADD, &CDatabaseLibDlg::OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_QUERY, &CDatabaseLibDlg::OnBnClickedButtonQuery)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_CHECK_ALL, &CDatabaseLibDlg::OnBnClickedCheckAll)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CDatabaseLibDlg::OnBnClickedButtonDelete)
	ON_BN_CLICKED(IDC_BTN_CREATETBL, &CDatabaseLibDlg::OnBnClickedBtnCreatetbl)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_USER, &CDatabaseLibDlg::OnNMDblclkListUser)
END_MESSAGE_MAP()

void CDatabaseLibDlg::AddItem(LPTSTR ID, LPTSTR Name, LPTSTR Age, LPTSTR Email)
{
	LVITEM lvi = { 0 };

	// Insert the item itself
	// Since we're always inserting item 0, new items will appear on top
	ListView_InsertItem(m_ctrl_user_list, &lvi);

	// Insert the subitems (columns)
	lvi.mask = LVIF_TEXT;
	lvi.iSubItem = 1;
	lvi.pszText = ID;
	ListView_SetItem(m_ctrl_user_list, &lvi);
	lvi.iSubItem++;
	lvi.pszText = Name;
	ListView_SetItem(m_ctrl_user_list, &lvi);
	lvi.iSubItem++;
	lvi.pszText = Age;
	ListView_SetItem(m_ctrl_user_list, &lvi);
	lvi.iSubItem++;
	lvi.pszText = Email;
	ListView_SetItem(m_ctrl_user_list, &lvi);

}

void CDatabaseLibDlg::AddSampleData(void)
{
	AddItem(_T("0"), _T("Gates"), _T("Microsoft"), _T("A@abc.net"));
	AddItem(_T("1"), _T("Ballmer"), _T("Microsoft"), _T("B@abc.net"));
	AddItem(_T("2"), _T("Jobs"), _T("Apple"), _T("C@abc.net"));
	AddItem(_T("3"), _T("Ellison"), _T("Oracle"), _T("D@abc.net"));
}

// CDatabaseLibDlg �޽��� ó����

BOOL CDatabaseLibDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�.  ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	
	LVCOLUMN lvcolumn;

	//m_ctrl_user_list.SetExtendedStyle(LVS_EX_GRIDLINES);
	//m_ctrl_user_list.SetExtendedStyle(m_ctrl_user_list.GetExtendedStyle() | LVS_EX_FLATSB | LVS_EX_CHECKBOXES | LVS_EX_GRIDLINES);
	//m_ctrl_user_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	// Set some styles for the list view control.  We want checkboxes and full row select.
	ListView_SetExtendedListViewStyle(m_ctrl_user_list, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT);

	// Add some columns to the list view control
	LVCOLUMN lvc = { 0 };
	ListView_InsertColumn(m_ctrl_user_list, 0, &lvc);
	lvc.mask = LVCF_TEXT;
	lvc.iSubItem++;
	lvc.pszText = _T("ID");
	ListView_InsertColumn(m_ctrl_user_list, 1, &lvc);
	lvc.iSubItem++;
	lvc.pszText = _T("Name");
	ListView_InsertColumn(m_ctrl_user_list, 2, &lvc);
	lvc.iSubItem++;
	lvc.pszText = _T("Age");
	ListView_InsertColumn(m_ctrl_user_list, 3, &lvc);
	lvc.iSubItem++;
	lvc.pszText = _T("Email");
	ListView_InsertColumn(m_ctrl_user_list, 4, &lvc);


	// Set column widths
	ListView_SetColumnWidth(m_ctrl_user_list, 0, LVSCW_AUTOSIZE_USEHEADER);
	ListView_SetColumnWidth(m_ctrl_user_list, 1, 100);
	ListView_SetColumnWidth(m_ctrl_user_list, 2, 150);
	ListView_SetColumnWidth(m_ctrl_user_list, 3, 110);
	ListView_SetColumnWidth(m_ctrl_user_list, 4, 282);

	// Here's where we can add the checkbox to the column header
	// First, we need to snag the header control and give it the
	// HDS_CHECKBOXES style since the list view doesn't do this for us
	HWND header = ListView_GetHeader(m_ctrl_user_list);
	DWORD dwHeaderStyle = ::GetWindowLong(header, GWL_STYLE);
	dwHeaderStyle |= HDS_CHECKBOXES;
	::SetWindowLong(header, GWL_STYLE, dwHeaderStyle);

	/*m_ctrl_user_list.InsertColumn(0, _T("User Name"), LVCFMT_LEFT, 100);
	m_ctrl_user_list.InsertColumn(1, _T("Password"), LVCFMT_LEFT, 150);
	m_ctrl_user_list.InsertColumn(2, _T("Employee Number"), LVCFMT_LEFT, 200);
	m_ctrl_user_list.InsertColumn(3, _T("Check"), LVCFMT_LEFT, 100);*/
	
	HDITEM hdi = { 0 };
	hdi.mask = HDI_FORMAT;
	Header_GetItem(header, 0, &hdi);
	hdi.fmt |= HDF_CHECKBOX | HDF_FIXEDWIDTH;
	Header_SetItem(header, 0, &hdi);

	// Add some sample data
	//AddSampleData();


	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void CDatabaseLibDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸�����
//  �Ʒ� �ڵ尡 �ʿ��մϴ�.  ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
//  �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CDatabaseLibDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�.
HCURSOR CDatabaseLibDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CDatabaseLibDlg::OnBnClickedButtonAdd()
{
	User dlg;
	int		id;
	CString	strNname;
	int	iAge;
	CString strEmail;

	Database *db = new Database();

	if (dlg.DoModal() == IDOK)
	{
		CString sql = "";
		USER_INFO Tx;

		Tx.Id= dlg.m_nId;
		Tx.Name = dlg.m_strName;
		Tx.Age= dlg.m_nAge;
		Tx.Email = dlg.m_strEmail;


		sql.Format("INSERT INTO [inalfa].[dbo].[Yourtable](Name, Age, Email) values ('%s', %d, '%s')", Tx.Name, Tx.Age, Tx.Email);
		SQLCHAR* insert_sql = (SQLCHAR*)(LPCTSTR)sql;

		if (db->DBConnection()){
			db->Insert(insert_sql);
			m_userList.push_back(Tx);
		}

		sql.Format("SELECT [ID],[Name],[Age],[Email] FROM [inalfa].[dbo].[Yourtable] order by ID desc");
		if (db->DBConnection()){
			SQLHANDLE datahdl = db->Retrieve((SQLCHAR*)(LPCTSTR)sql);

			if (datahdl != NULL){

				SQLCHAR sqlVersion[SQL_RESULT_LEN];
				SQLCHAR ID[SQL_RESULT_LEN], Name[SQL_RESULT_LEN], Age[SQL_RESULT_LEN], Email[SQL_RESULT_LEN];
				SQLINTEGER length, Emp;

				int nIndex = 0;
				m_ctrl_user_list.UpdateWindow();
				m_ctrl_user_list.DeleteAllItems();

				while (SQLFetch(datahdl) == SQL_SUCCESS) {
					SQLGetData(datahdl, 1, SQL_CHAR, ID, SQL_RESULT_LEN, &length);
					SQLGetData(datahdl, 2, SQL_CHAR, Name, SQL_RESULT_LEN, &length);
					SQLGetData(datahdl, 3, SQL_CHAR, Age, SQL_RESULT_LEN, &length);
					SQLGetData(datahdl, 4, SQL_CHAR, Email, SQL_RESULT_LEN, &length);
					AddItem((LPTSTR)ID, (LPTSTR)Name, (LPTSTR)Age, (LPTSTR)Email);

				}

				db->CloseConnection();
			}

		}
		

	}
}


void CDatabaseLibDlg::OnBnClickedButtonQuery()
{
	CString sql = "";
	Database *db = new Database();

	sql.Format("SELECT [ID],[Name],[Age],[Email] FROM [inalfa].[dbo].[Yourtable] order by ID desc");
	if (db->DBConnection()){
		SQLHANDLE datahdl = db->Retrieve((SQLCHAR*)(LPCTSTR)sql);

		if (datahdl != NULL){

			SQLCHAR sqlVersion[SQL_RESULT_LEN];
			SQLCHAR ID[SQL_RESULT_LEN], Name[SQL_RESULT_LEN], Age[SQL_RESULT_LEN], Email[SQL_RESULT_LEN];
			SQLINTEGER length, Emp;

			int nIndex = 0;
			m_ctrl_user_list.UpdateWindow();
			m_ctrl_user_list.DeleteAllItems();

			while (SQLFetch(datahdl) == SQL_SUCCESS) {
				SQLGetData(datahdl, 1, SQL_CHAR, ID, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 2, SQL_CHAR, Name, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 3, SQL_CHAR, Age, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 4, SQL_CHAR, Email, SQL_RESULT_LEN, &length);
				AddItem((LPTSTR)ID, (LPTSTR)Name, (LPTSTR)Age, (LPTSTR)Email);

			}

			db->CloseConnection();
		}

	}
}


void CDatabaseLibDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);
	
	//m_ctrl_user_list.SetWindowPos(NULL, m_ctrl_user_list.GetWindowRect()

	// TODO: Add your message handler code here
}

void CDatabaseLibDlg::CheckAllItems(BOOL fChecked) {
	for (int nItem = 0; nItem < ListView_GetItemCount(m_ctrl_user_list); nItem++) {
		ListView_SetCheckState(m_ctrl_user_list, nItem, fChecked);
	}
}

void CDatabaseLibDlg::OnBnClickedCheckAll()
{
	CheckAllItems(m_ctrl_checkAll.GetCheck());
}


void CDatabaseLibDlg::OnBnClickedButtonDelete()
{
	Database *db = new Database();
	CString sql = "DELETE FROM [inalfa].[dbo].[Yourtable] WHERE ID in";
	CString set = "(";
	LPTSTR pszUserName;
	LPTSTR chpszUserName;
	LVITEM lvi = { 0 };

	if (!db->DBConnection())
		return;

	for (int nItem = 0; nItem < ListView_GetItemCount(m_ctrl_user_list); nItem++) 
	{	
		if (ListView_GetCheckState(m_ctrl_user_list, nItem)) 
		{
			//ListView_GetItemText(m_ctrl_user_list, (LPTSTR)nItem, pszUserName, chpszUserName);
			//ListView_GetItem(m_ctrl_user_list, &lvi);

			//BOOL b = m_ctrl_user_list.GetItem(&lvi);
			
			//CString sid = m_ctrl_user_list.GetItemText(m_ctrl_user_list.GetSelectionMark(), 0);
			CString sItem = m_ctrl_user_list.GetItemText(nItem, 1);
			//int id = atoi(sItem);
			set += sItem + ",";
	
		}

	}

	if (set == "("){
		//nothing to delete, no id seclected
		db->CloseConnection();
	}
	else{
		sql.Append(set);
		sql = sql.Mid(0, sql.GetLength() - 1);
		sql.Append(");");
		db->Delete((SQLCHAR*)(LPCTSTR)sql);
		db->CloseConnection();

		OnBnClickedButtonQuery();
	}

}

void CDatabaseLibDlg::OnBnClickedBtnCreatetbl()
{
	Database *db = new Database();
	CString createTbl = "USE [inalfa] IF OBJECT_ID(N'dbo.Yourtable', N'U') IS NOT NULL drop table Yourtable CREATE TABLE [dbo].[YourTable]([ID][int] NOT NULL IDENTITY(1,1), [Name][nvarchar](50) NOT NULL,[Age][int] NOT NULL,[Email][nvarchar](50) NULL,PRIMARY KEY([ID])) ON[PRIMARY];";
	bool rt = false;
	if (db->DBConnection()){
		rt = db->CreateTable((SQLCHAR*)(LPCTSTR)createTbl);

		if (rt)
			MessageBox("Created Table successfully");
		else
			MessageBox("Creat Table failed");
		db->CloseConnection();
	}

}


void CDatabaseLibDlg::OnNMDblclkListUser(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	CString sql = "";
	Database *db = new Database();

	int currentItm = m_ctrl_user_list.GetSelectionMark();
	CString sId = m_ctrl_user_list.GetItemText(currentItm, 1);



	sql.Format("SELECT [ID],[Name],[Age],[Email] FROM [inalfa].[dbo].[Yourtable] where ID =" + sId);
	if (db->DBConnection()){
		SQLHANDLE datahdl = db->Retrieve((SQLCHAR*)(LPCTSTR)sql);

		if (datahdl != NULL){

			SQLCHAR sqlVersion[SQL_RESULT_LEN];
			SQLCHAR ID[SQL_RESULT_LEN], Name[SQL_RESULT_LEN], Age[SQL_RESULT_LEN], Email[SQL_RESULT_LEN];
			SQLINTEGER length, Emp;

			int nIndex = 0;
			m_ctrl_user_list.UpdateWindow();

			if(SQLFetch(datahdl) == SQL_SUCCESS) 
			{
				SQLGetData(datahdl, 1, SQL_CHAR, ID, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 2, SQL_CHAR, Name, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 3, SQL_CHAR, Age, SQL_RESULT_LEN, &length);
				SQLGetData(datahdl, 4, SQL_CHAR, Email, SQL_RESULT_LEN, &length);
				
				USER_INFO Tx;
				User dlg;
				dlg.m_nId = atoi((char*)ID);
				dlg.m_strName = Name;
				dlg.m_nAge = atoi((char*)Age);
				dlg.m_strEmail = Email;

				Tx.Id = dlg.m_nId;
				Tx.Name = dlg.m_strName;
				Tx.Age = dlg.m_nAge;
				Tx.Email = dlg.m_strEmail;

				if (dlg.DoModal() == IDOK){

					CString rName = dlg.m_strName;
					int rAge = dlg.m_nAge;
					CString rEmail = dlg.m_strEmail;

					if ((Tx.Name == rName) && (Tx.Age == rAge) && (Tx.Email == rEmail)){
						//do nothing, because nothing to update
					}
					else{
						sql.Format("UPDATE [inalfa].[dbo].[YourTable] SET [Name] ='%s' , [Age] = %d, [Email] = '%s'  WHERE ID = %d", rName, rAge, rEmail, atoi(sId));
						if (!db->Update((SQLCHAR*)(LPCTSTR)sql))
						{
							MessageBox("Update failed");
						}
					}
						
				}

			}

			db->CloseConnection();

			OnBnClickedButtonQuery();
		}

	}

	// TODO: Add your control notification handler code here
	*pResult = 0;
}
