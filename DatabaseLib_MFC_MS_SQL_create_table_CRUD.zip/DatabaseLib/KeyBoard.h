//{{AFX_INCLUDES()
#include "pbutton.h"
#include "plabel.h"
//}}AFX_INCLUDES

#include "resource.h"
#if !defined(AFX_KEYBOARD_H__1F4AF8E1_09BE_4F23_A452_774681CD9FAB__INCLUDED_)
#define AFX_KEYBOARD_H__1F4AF8E1_09BE_4F23_A452_774681CD9FAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeyBoard.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CKeyBoard dialog

class CKeyBoard : public CDialog
{
// Construction
public:
	CKeyBoard(CWnd* pParent = NULL);   // standard constructor
	virtual ~CKeyBoard();
	void CommentSet(CString str, int x, int y);
	void CommentSet(CString str, int x, int y, CString sData);
	void DispComment();
	CString m_strComment;
	CPoint m_pSrt;

	BOOL PreTranslateMessage(MSG* pMsg);

// Dialog Data
	//{{AFX_DATA(CKeyBoard)
	enum { IDD = IDD_DLG_KEYBOARD };
	CString	m_strKeyBDDisplay;
	CPButton	m_ctrlCaps;
	CPLabel	m_ctrlComment;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyBoard)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CKeyBoard)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnClickCancel2();
	afx_msg void OnClickButton41();
	afx_msg void OnClickButton15();
	afx_msg void OnClickButton28();
	afx_msg void OnClickButton29();
	afx_msg void OnClickButton1();
	afx_msg void OnClickButton2();
	afx_msg void OnClickButton3();
	afx_msg void OnClickButton4();
	afx_msg void OnClickButton5();
	afx_msg void OnClickButton6();
	afx_msg void OnClickButton7();
	afx_msg void OnClickButton8();
	afx_msg void OnClickButton9();
	afx_msg void OnClickButton10();
	afx_msg void OnClickButton11();
	afx_msg void OnClickButton12();
	afx_msg void OnClickButton13();
	afx_msg void OnClickButton14();
	afx_msg void OnClickButton16();
	afx_msg void OnClickButton17();
	afx_msg void OnClickButton18();
	afx_msg void OnClickButton19();
	afx_msg void OnClickButton20();
	afx_msg void OnClickButton21();
	afx_msg void OnClickButton22();
	afx_msg void OnClickButton23();
	afx_msg void OnClickButton24();
	afx_msg void OnClickButton25();
	afx_msg void OnClickButton26();
	afx_msg void OnClickButton27();
	afx_msg void OnClickButton30();
	afx_msg void OnClickButton31();
	afx_msg void OnClickButton32();
	afx_msg void OnClickButton33();
	afx_msg void OnClickButton34();
	afx_msg void OnClickButton35();
	afx_msg void OnClickButton36();
	afx_msg void OnClickButton37();
	afx_msg void OnClickButton38();
	afx_msg void OnClickButton39();
	afx_msg void OnClickButton40();
	afx_msg void OnClickButton42();
	afx_msg void OnClickButton43();
	afx_msg void OnClickButton44();
	afx_msg void OnClickButton45();
	afx_msg void OnClickButton46();
	afx_msg void OnClickButton47();
	afx_msg void OnClickButton48();
	afx_msg void OnClickButton49();
	afx_msg void OnClickButton50();
	afx_msg void OnClickButton51();
	afx_msg void OnClickButton52();
	afx_msg void OnClickButton53();
	afx_msg void OnClickButton54();
	afx_msg void OnClickButton55();
	afx_msg void OnClickButton56();
	afx_msg void OnClickButton57();
	afx_msg void OnClickButton58();
	afx_msg void OnClickButton59();
	afx_msg void OnClickButton60();
	afx_msg void OnClickButton61();
	afx_msg void OnClickButton62();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYBOARD_H__1F4AF8E1_09BE_4F23_A452_774681CD9FAB__INCLUDED_)
