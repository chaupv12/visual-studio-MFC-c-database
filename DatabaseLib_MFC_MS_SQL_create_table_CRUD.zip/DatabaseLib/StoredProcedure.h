// StoredProcedure.h : header file
//

#include "afxdb.h"
/////////////////////////////////////////////////////////////////////////////
// StoredProcedure recordset

class StoredProcedure : public CRecordset
{
public:
	StoredProcedure(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(StoredProcedure)

	// Field/Param Data
	//{{AFX_FIELD(StoredProcedure, CRecordset)
	long m_retRETURN_VALUE;
	CString m_paramInputParam;  //The input param 
	CString m_paramOutputParam; //The output param 
	//}}AFX_FIELD

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StoredProcedure)
public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	virtual void Move(long nRows, WORD wFetchType = SQL_FETCH_RELATIVE);
	//}}AFX_VIRTUAL

	// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};