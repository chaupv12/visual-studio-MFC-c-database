// DialogTenkey.cpp : implementation file
//

#include "stdafx.h"
#include "DialogTenkey.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogTenkey dialog


CDialogTenkey::CDialogTenkey(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogTenkey::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogTenkey)
	m_strTenKeyDisplay = _T("");
	//}}AFX_DATA_INIT
	m_nTenKeyNumber=0;
	/*
	nSrtX = 900;
	nSrtY = 300;
	*/
	nSrtX = 450;
	nSrtY = 250;
}

CDialogTenkey::~CDialogTenkey()
{
}

void CDialogTenkey::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogTenkey)
	DDX_Text(pDX, IDC_EDIT_DISPLAY, m_strTenKeyDisplay);
	//DDX_Control(pDX, IDC_MIN_VALUE, m_ctrlMinValue);
	//DDX_Control(pDX, IDC_MAX_VALUE, m_ctrlMaxValue);
	DDX_Control(pDX, IDC_COMMENT, m_ctrlComment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogTenkey, CDialog)
	//{{AFX_MSG_MAP(CDialogTenkey)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogTenkey message handlers

BOOL CDialogTenkey::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
//	SetWindowPos(NULL, nSrtX + SCREEN_POS, nSrtY, 370, 540, SWP_SHOWWINDOW);

	SetWindowPos(NULL, nSrtX + 0 + 840, nSrtY + 56, 370, 540, SWP_SHOWWINDOW);

	InitControl();
	DispComment();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BEGIN_EVENTSINK_MAP(CDialogTenkey, CDialog)
    //{{AFX_EVENTSINK_MAP(CDialogTenkey)
	ON_EVENT(CDialogTenkey, IDCANCEL2, 22 /* Click */, OnClickCancel2, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
	ON_EVENT(CDialogTenkey, IDC_NUM_0, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum0, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_1, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum1, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_2, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum2, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_3, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum3, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_4, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum4, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_5, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum5, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_6, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum6, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_7, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum7, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_8, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum8, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_9, DISPID_MOUSEUP, CDialogTenkey::MouseUpNum9, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_DOT, DISPID_MOUSEUP, CDialogTenkey::MouseUpNumDot, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUM_MINUS, DISPID_MOUSEUP, CDialogTenkey::MouseUpNumMinus, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUMBER_BACK, DISPID_MOUSEUP, CDialogTenkey::MouseUpNumberBack, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUMBER_CLR, DISPID_MOUSEUP, CDialogTenkey::MouseUpNumberClr, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogTenkey, IDC_NUMBER_ENT, DISPID_MOUSEUP, CDialogTenkey::MouseUpNumberEnt, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
END_EVENTSINK_MAP()


void CDialogTenkey::InitControl()
{
	CFont font1;
	font1.CreateFont(21, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, 0, 0, 0, 0, 0, "Arial Black");
//	IDC_EDIT_DISPLAY
	//((CEdit *)GetDlgItem(IDC_EDIT_DISPLAY))->Set
	CEdit* pCttlEdit = (CEdit*)GetDlgItem(IDC_EDIT_DISPLAY);
	pCttlEdit->SetFont(&font1);

	pCttlEdit->SetPasswordChar(0); //password ��yAUC�ͨ�A
	
	//m_strTenKeyDisplay
}



void CDialogTenkey::CommentSet(double dMin, double dMax, CString str, int nX, int nY)
{
	m_dMin = dMin; 
	m_dMax = dMax; 
	m_strComment = str;
	nSrtX = nX;
	nSrtY = nY;
}
void CDialogTenkey::CommentSet(double dMin, double dMax, CString str)
{
	m_dMin = dMin; 
	m_dMax = dMax; 
	m_strComment = str;
	nSrtX = 450;
	nSrtY = 250;
}

void CDialogTenkey::DispComment()
{
	CString str[3] = {"",};
	str[0].Format( _T("%s"), m_strComment);
	str[1].Format( _T("%.3f"), m_dMin);	
	str[2].Format( _T("%.3f"), m_dMax);

	m_ctrlComment.SetCaption(str[0]);
	//m_ctrlMinValue.SetCaption(str[1]);
	//m_ctrlMaxValue.SetCaption(str[2]);
}

void CDialogTenkey::OnClickCancel2() 
{
	OnCancel();	
}

void CDialogTenkey::MouseUpNum0(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '0');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum1(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '1');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum2(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '2');

	UpdateData(FALSE);
}

void CDialogTenkey::MouseUpNum3(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '3');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum4(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '4');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum5(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '5');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum6(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '6');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum7(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '7');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum8(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '8');

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNum9(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(),'9');

	UpdateData(FALSE);		
}


void CDialogTenkey::MouseUpNumDot(short Button, short Shift, long x, long y)
{

	UpdateData(TRUE);
	m_strTenKeyDisplay.Insert(m_strTenKeyDisplay.GetLength(), '.');
	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNumMinus(short Button, short Shift, long x, long y)
{

	UpdateData(TRUE);

	if (m_strTenKeyDisplay.Left(1) == _T("-"))
	{
		m_strTenKeyDisplay.Delete(0, 1);
	}

	else
	{
		m_strTenKeyDisplay.Insert(0, '-');
	}

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNumberBack(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);
	if (m_strTenKeyDisplay.GetLength() >= 1)
		m_strTenKeyDisplay.Delete(m_strTenKeyDisplay.GetLength() - 1, 1);

	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNumberClr(short Button, short Shift, long x, long y)
{
	m_strTenKeyDisplay.Empty();
	UpdateData(FALSE);
}


void CDialogTenkey::MouseUpNumberEnt(short Button, short Shift, long x, long y)
{
	UpdateData(TRUE);

	EndDialog(IDOK);
}

BOOL CDialogTenkey::PreTranslateMessage(MSG* pMsg)  // Eenter Esc

{

	if (pMsg->message == WM_KEYDOWN && pMsg->hwnd == GetDlgItem(IDC_EDIT_DISPLAY)->m_hWnd && pMsg->wParam == VK_RETURN)
	{
		UpdateData(TRUE);

		EndDialog(IDOK);
	}


	if (pMsg->message == WM_KEYDOWN && pMsg->hwnd == GetDlgItem(IDC_EDIT_DISPLAY)->m_hWnd && pMsg->wParam == VK_ESCAPE)
	{
		OnCancel();
	}

	return CDialog::PreTranslateMessage(pMsg);

}
