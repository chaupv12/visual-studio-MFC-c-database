#pragma once
#include "afxwin.h"
#include "plabel.h"
#include "edit_id.h"

// User dialog

class User : public CDialog
{
	DECLARE_DYNAMIC(User)

public:
	User(CWnd* pParent = NULL);   // standard constructor
	virtual ~User();

// Dialog Data
	enum { IDD = IDD_USER };

	int		m_nId;
	CString	m_strName;
	int	m_nAge;
	CString m_strEmail;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	virtual BOOL PreTranslateMessage(MSG* pMsg);

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

	afx_msg void OnClick();

public:
	DECLARE_EVENTSINK_MAP()
	CEdit_id m_ctrlID;
	CEdit_id m_ctrlName;
	CEdit_id m_ctrlAge;
	CEdit_id m_ctrlEmail;
	void ClickEditId();
	void ClickEditName();
	void ClickEditAge();
	void ClickEditEmail();
	afx_msg void OnBnClickedOk();
};
