// KeyBoard.cpp : implementation file
//

#include "stdafx.h"
#include "KeyBoard.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyBoard dialog


CKeyBoard::CKeyBoard(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyBoard::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeyBoard)
	m_strKeyBDDisplay = _T("");
	//}}AFX_DATA_INIT
	m_pSrt.x = 480;
	m_pSrt.y = 550;

}

CKeyBoard::~CKeyBoard()
{
}

void CKeyBoard::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeyBoard)
	DDX_Text(pDX, IDC_EDIT_DISPLAY, m_strKeyBDDisplay);
	DDX_Control(pDX, IDC_BUTTON29, m_ctrlCaps);
	DDX_Control(pDX, IDC_COMMENT, m_ctrlComment);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeyBoard, CDialog)
	//{{AFX_MSG_MAP(CKeyBoard)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyBoard message handlers

BOOL CKeyBoard::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	DispComment();
	((CEdit *)GetDlgItem(IDC_EDIT_DISPLAY))->SetSel(0, -1);
	((CEdit *)GetDlgItem(IDC_EDIT_DISPLAY))->SetSel(-1, -1);

	GetDlgItem(IDC_EDIT_DISPLAY)->SetFocus();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CKeyBoard::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CDialog::OnPaint() for painting messages
}

BEGIN_EVENTSINK_MAP(CKeyBoard, CDialog)
    //{{AFX_EVENTSINK_MAP(CKeyBoard)
	ON_EVENT(CKeyBoard, IDCANCEL2, 22 /* Click */, OnClickCancel2, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON41, -600 /* Click */, OnClickButton41, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON15, -600 /* Click */, OnClickButton15, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON28, -600 /* Click */, OnClickButton28, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON29, -600 /* Click */, OnClickButton29, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON1, -600 /* Click */, OnClickButton1, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON2, -600 /* Click */, OnClickButton2, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON3, -600 /* Click */, OnClickButton3, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON4, -600 /* Click */, OnClickButton4, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON5, -600 /* Click */, OnClickButton5, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON6, -600 /* Click */, OnClickButton6, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON7, -600 /* Click */, OnClickButton7, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON8, -600 /* Click */, OnClickButton8, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON9, -600 /* Click */, OnClickButton9, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON10, -600 /* Click */, OnClickButton10, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON11, -600 /* Click */, OnClickButton11, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON12, -600 /* Click */, OnClickButton12, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON13, -600 /* Click */, OnClickButton13, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON14, -600 /* Click */, OnClickButton14, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON16, -600 /* Click */, OnClickButton16, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON17, -600 /* Click */, OnClickButton17, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON18, -600 /* Click */, OnClickButton18, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON19, -600 /* Click */, OnClickButton19, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON20, -600 /* Click */, OnClickButton20, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON21, -600 /* Click */, OnClickButton21, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON22, -600 /* Click */, OnClickButton22, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON23, -600 /* Click */, OnClickButton23, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON24, -600 /* Click */, OnClickButton24, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON25, -600 /* Click */, OnClickButton25, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON26, -600 /* Click */, OnClickButton26, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON27, -600 /* Click */, OnClickButton27, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON30, -600 /* Click */, OnClickButton30, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON31, -600 /* Click */, OnClickButton31, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON32, -600 /* Click */, OnClickButton32, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON33, -600 /* Click */, OnClickButton33, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON34, -600 /* Click */, OnClickButton34, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON35, -600 /* Click */, OnClickButton35, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON36, -600 /* Click */, OnClickButton36, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON37, -600 /* Click */, OnClickButton37, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON38, -600 /* Click */, OnClickButton38, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON39, -600 /* Click */, OnClickButton39, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON40, -600 /* Click */, OnClickButton40, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON42, -600 /* Click */, OnClickButton42, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON43, -600 /* Click */, OnClickButton43, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON44, -600 /* Click */, OnClickButton44, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON45, -600 /* Click */, OnClickButton45, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON46, -600 /* Click */, OnClickButton46, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON47, -600 /* Click */, OnClickButton47, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON48, -600 /* Click */, OnClickButton48, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON49, -600 /* Click */, OnClickButton49, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON50, -600 /* Click */, OnClickButton50, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON51, -600 /* Click */, OnClickButton51, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON52, -600 /* Click */, OnClickButton52, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON53, -600 /* Click */, OnClickButton53, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON54, -600 /* Click */, OnClickButton54, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON55, -600 /* Click */, OnClickButton55, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON56, -600 /* Click */, OnClickButton56, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON57, -600 /* Click */, OnClickButton57, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON58, -600 /* Click */, OnClickButton58, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON59, -600 /* Click */, OnClickButton59, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON60, -600 /* Click */, OnClickButton60, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON61, -600 /* Click */, OnClickButton61, VTS_NONE)
	ON_EVENT(CKeyBoard, IDC_BUTTON62, -600 /* Click */, OnClickButton62, VTS_NONE)
	//}}AFX_EVENTSINK_MAP

END_EVENTSINK_MAP()

void CKeyBoard::CommentSet(CString str, int x, int y)
{
	m_pSrt.x = x;
	m_pSrt.y = y;
	m_strComment = str;
}

void CKeyBoard::CommentSet(CString str, int x, int y, CString sData) //Check Ok
{
	m_pSrt.x = x;
	m_pSrt.y = y;
	m_strComment = str;
	m_strKeyBDDisplay = sData;
}

void CKeyBoard::DispComment()
{
//	SetWindowPos(NULL, m_pSrt.x + SCREEN_POS, m_pSrt.y, 1, 1, SWP_NOSIZE | SWP_SHOWWINDOW);


	SetWindowPos(NULL, m_pSrt.x + 0 + 840, m_pSrt.y + 56, 1, 1, SWP_NOSIZE | SWP_SHOWWINDOW);

	CString str = "";
	str.Format("%s", m_strComment);
	m_ctrlComment.SetCaption(str);
}

void CKeyBoard::OnClickCancel2() 
{
	OnCancel();		
}

void CKeyBoard::OnClickButton41()	// Enter
{
	UpdateData(TRUE);	
	EndDialog(IDOK);		
}

void CKeyBoard::OnClickButton15()	// Back
{
	if(m_strKeyBDDisplay.GetLength() >= 1)
		m_strKeyBDDisplay.Delete(m_strKeyBDDisplay.GetLength()-1,1);
	UpdateData(FALSE);				// ���� => ��Ʈ��
}

void CKeyBoard::OnClickButton28()	// Clear
{
	m_strKeyBDDisplay.Empty();
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton29()	// Caps
{
	if(m_ctrlCaps.GetLamp()==2)	m_ctrlCaps.SetLamp(1);
	else m_ctrlCaps.SetLamp(2);
}

void CKeyBoard::OnClickButton1() // ~
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'~');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton2() // !
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'!');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton3() // @
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'@');
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton4() //#
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'#');
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton5() // $
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'$');
	UpdateData(FALSE);				
}

void CKeyBoard::OnClickButton6() // %
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'%');
	UpdateData(FALSE);	
}


void CKeyBoard::OnClickButton7() // ^
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'^');
	UpdateData(FALSE);		
}



void CKeyBoard::OnClickButton8() // &
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'&');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton9() // *
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'*');
	UpdateData(FALSE);		
}


void CKeyBoard::OnClickButton10() // (
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'(');
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton11() // )
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),')');
	UpdateData(FALSE);				
}


void CKeyBoard::OnClickButton12() // _
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'_');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton13() // +
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'+');
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton14() // |
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'|');
	UpdateData(FALSE);			
}

// Lamp ==> 1: On, 2: Off
void CKeyBoard::OnClickButton16() // q
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'q');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'Q');
	UpdateData(FALSE);				
}

void CKeyBoard::OnClickButton17() // w
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'w');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'W');
	UpdateData(FALSE);
}

void CKeyBoard::OnClickButton18() // e
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'e');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'E');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton19() // r
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'r');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'R');
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton20() // t
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'t');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'T');
	UpdateData(FALSE);
}

void CKeyBoard::OnClickButton21() // y
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'y');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'Y');
	UpdateData(FALSE);
}

void CKeyBoard::OnClickButton22() // u
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'u');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'U');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton23() // i
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'i');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'I');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton24() // o
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'o');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'O');
	UpdateData(FALSE);		
}


void CKeyBoard::OnClickButton25() // p
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'p');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'P');
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton26() // [
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'[');	
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton27() // ]
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),']');	
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton30() // a
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'a');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'A');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton31() // s
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'s');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'S');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton32() // d
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'d');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'D');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton33() // f
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'f');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'F');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton34() // g
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'g');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'G');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton35() // h
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'h');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'H');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton36() // j
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'j');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'J');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton37() // k
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'k');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'K');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton38() // l
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'l');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'L');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton39() // ;
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),';');	
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton40() // '
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'\'');	
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton42() // z
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'z');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'Z');
	UpdateData(FALSE);
}

void CKeyBoard::OnClickButton43() // x
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'x');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'X');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton44() //c
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'c');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'C');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton45() // v
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'v');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'V');
	UpdateData(FALSE);}

void CKeyBoard::OnClickButton46() // b
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'b');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'B');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton47() //n
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'n');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'N');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton48() //m
{
	if(m_ctrlCaps.GetLamp()==2)	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'m');
	else						m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'M');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton49() // ,
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),',');
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton50() // .
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'.');
	UpdateData(FALSE);
}

void CKeyBoard::OnClickButton51() // /
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'/');	
	UpdateData(FALSE);	
}

void CKeyBoard::OnClickButton52() // Space
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),' ');	
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton53() // '1'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'1');	
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton54() // '2'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'2');	
	UpdateData(FALSE);		
}

void CKeyBoard::OnClickButton55() //'3'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'3');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton56() //'4'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'4');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton57() // '5'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'5');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton58() // '6'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'6');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton59() // '7'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'7');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton60() // '8'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'8');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton61() // '9'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'9');	
	UpdateData(FALSE);			
}

void CKeyBoard::OnClickButton62() // '0'
{
	m_strKeyBDDisplay.Insert(m_strKeyBDDisplay.GetLength(),'0');	
	UpdateData(FALSE);			
}

BOOL CKeyBoard::PreTranslateMessage(MSG* pMsg)  // Eenter Esc

{

	if (pMsg->message == WM_KEYDOWN && pMsg->hwnd == GetDlgItem(IDC_EDIT_DISPLAY)->m_hWnd && pMsg->wParam == VK_RETURN)
	{
		UpdateData(TRUE);
		EndDialog(IDOK);
	}


	if (pMsg->message == WM_KEYDOWN && pMsg->hwnd == GetDlgItem(IDC_EDIT_DISPLAY)->m_hWnd && pMsg->wParam == VK_ESCAPE)
	{
		OnCancel();
	}

	return CDialog::PreTranslateMessage(pMsg);

}