#include "stdafx.h"

#include "Database.h"

Database::Database()
{
	m_connectionString = CONNECTION_STR;
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
}


Database::~Database()
{
	CloseConnection();
}

void Database::CloseConnection()
{
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
}

BOOL Database::DBConnection()
{
	BOOL ret = FALSE;
	
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle)){
		CloseConnection();
		ret = FALSE;
	}
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0)){
		ret = FALSE;
		CloseConnection();
	}
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle)){
		ret = FALSE;
		CloseConnection();
	}

	int conectionState = SQLDriverConnect(sqlConnHandle, NULL, (SQLCHAR*)CONNECTION_STR, SQL_NTS, (SQLCHAR*)retconstring, 1024, NULL, SQL_DRIVER_NOPROMPT);

	switch (conectionState) {

	case SQL_SUCCESS:
		//Successfully connected to SQL Server
		ret = TRUE;
		break;
	case SQL_SUCCESS_WITH_INFO:
		//Successfully connected to SQL Server
		ret = TRUE;
		break;
	case SQL_INVALID_HANDLE:
		//Could not connect to SQL Server
		CloseConnection();
		ret = FALSE;
		break;
	case SQL_ERROR:
		//Could not connect to SQL Server
		CloseConnection();
		ret = FALSE;
		break;

	default:
		return FALSE;
	}

	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle)){
		CloseConnection();
		ret = FALSE;
	}

	return ret;
}

BOOL Database::Insert(SQLCHAR* insert_str){
	/*BOOL ret = FALSE;
	
	if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, insert_str, SQL_NTS)) {
		//Error inserting SQL Server;
		CloseConnection();
		ret = FALSE;
	}
	else
		ret = TRUE;

	return ret;
	*/
	BOOL ret = FALSE;
	CDatabase m_db;

	m_db.OpenEx(CONNECTION_STR);

	if (!m_db.IsOpen() && !m_db.OpenEx(NULL))
		ret = FALSE;

	try
	{
		m_db.ExecuteSQL((LPCSTR)insert_str);
		ret = true;
	}
	catch (CDBException *pe)
	{
		// The error code is in pe->m_nRetCode
		pe->ReportError();
		pe->Delete();
		ret = false;
	}

	return ret;
}

BOOL Database::Update(SQLCHAR* update_str){
	BOOL ret = FALSE;

	//if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, update_str, SQL_NTS)) {
	//	//Error updateting SQL Server;
	//	CloseConnection();
	//	ret = FALSE;
	//}
	//else
	//	ret = TRUE;
	CDatabase m_db;

	m_db.OpenEx(CONNECTION_STR);

	if (!m_db.IsOpen() && !m_db.OpenEx(NULL))
		ret = FALSE;

	try
	{
		m_db.ExecuteSQL((LPCSTR)update_str);
		ret = true;
	}
	catch (CDBException *pe)
	{
		// The error code is in pe->m_nRetCode
		pe->ReportError();
		pe->Delete();
		ret = false;
	}

	return ret;
}

BOOL Database::Delete(SQLCHAR* delete_str){
	BOOL ret = FALSE;

	if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, delete_str, SQL_NTS)) {
		//Error deleting SQL Server;
		CloseConnection();
		ret = FALSE;
	}
	else
		ret = TRUE;

	return ret;
}

BOOL Database::CreateTable(SQLCHAR *sqlCreatetblName){

	BOOL ret = FALSE;

	CDatabase m_dbCust;

	m_dbCust.OpenEx(CONNECTION_STR);

	if (!m_dbCust.IsOpen() && !m_dbCust.OpenEx(NULL))
		ret = FALSE;

	try
	{
		m_dbCust.ExecuteSQL((LPCSTR)sqlCreatetblName);
		ret = true;
	}
	catch (CDBException *pe)
	{
		// The error code is in pe->m_nRetCode
		pe->ReportError();
		pe->Delete();
		ret = false;
	}

	//if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, sqlCreatetblName, SQL_NTS)) {
	//	//Error deleting SQL Server;
	//	CloseConnection();
	//	ret = FALSE;
	//}
	//else
	//	ret = TRUE;

	return ret;

}

SQLHANDLE Database::Retrieve(SQLCHAR* sql_query){

	if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, sql_query, SQL_NTS)) {
		//Error querying SQL Server
		CloseConnection();
		return NULL;
	}
	else {
		return sqlStmtHandle;
	}

}