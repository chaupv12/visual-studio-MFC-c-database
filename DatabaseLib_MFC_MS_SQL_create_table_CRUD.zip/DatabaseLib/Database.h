#pragma once
#include "stdafx.h"
#include "afxdb.h"
#include "atlstr.h";

#include <iostream>
#include <windows.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>

#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000

#define CONNECTION_STR "DRIVER=ODBC Driver 18 for SQL Server; UID=user1;PWD=3131; TrustServerCertificate=Yes; WSID=PARKHONGHWAN; Trusted_Connection=No; SERVER=PARKHONGHWAN; Description=inalfa;"

#pragma comment(lib,"odbc32.lib")

class Database
{
public:

	Database();
	~Database();

	CString m_connectionString;

	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];

	BOOL DBConnection();

	void CloseConnection();

	BOOL Insert(SQLCHAR* insert_str);

	BOOL Delete(SQLCHAR* delete_str);

	BOOL Update(SQLCHAR* update_str);

	SQLHANDLE Retrieve(SQLCHAR* sql_query);

	BOOL CreateTable(SQLCHAR *tblName);

};

