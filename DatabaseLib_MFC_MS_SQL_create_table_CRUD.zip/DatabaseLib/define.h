#include "stdafx.h"
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
#include <vector>

typedef struct tagUserInfo		// User Log
{
	int	Id;
	CString	Name;
	int Age;
	CString Email;
}USER_INFO;

typedef std::vector<USER_INFO>	ARRAY_USER_INFO;