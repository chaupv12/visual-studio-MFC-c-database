// User.cpp : implementation file
//

#include "stdafx.h"
#include "DatabaseLib.h"
#include "User.h"
#include "afxdialogex.h"

#include "DialogTenkey.h"
#include "KeyBoard.h"

// User dialog

IMPLEMENT_DYNAMIC(User, CDialog)

User::User(CWnd* pParent /*=NULL*/)
	: CDialog(User::IDD, pParent)
{

}

User::~User()
{
}

void User::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_ID, m_ctrlID);
	DDX_Control(pDX, IDC_EDIT_NAME, m_ctrlName);
	DDX_Control(pDX, IDC_EDIT_AGE, m_ctrlAge);
	DDX_Control(pDX, IDC_EDIT_EMAIL, m_ctrlEmail);
}


BEGIN_MESSAGE_MAP(User, CDialog)
	ON_BN_CLICKED(IDOK, &User::OnBnClickedOk)
END_MESSAGE_MAP()


// User message handlers
BEGIN_EVENTSINK_MAP(User, CDialog)
	ON_EVENT(User, IDC_EDIT_ID, DISPID_CLICK, User::ClickEditId, VTS_NONE)
	ON_EVENT(User, IDC_EDIT_NAME, DISPID_CLICK, User::ClickEditName, VTS_NONE)
	ON_EVENT(User, IDC_EDIT_AGE, DISPID_CLICK, User::ClickEditAge, VTS_NONE)
	ON_EVENT(User, IDC_EDIT_EMAIL, DISPID_CLICK, User::ClickEditEmail, VTS_NONE)
END_EVENTSINK_MAP()

BOOL User::PreTranslateMessage(MSG *pMsg)
{
	//if ((pMsg->wParam == VK_LBUTTON) && (m_ctrlUsrName.m_hWnd == pMsg->hwnd))
	//{
	//	// open your file dialog
	//	return TRUE; // Return that the message was translated and doesn't need to be dispatched
	//}
	return CDialog::PreTranslateMessage(pMsg);
}


BOOL User::OnInitDialog()
{
	CDialog::OnInitDialog();

	if (m_nId != NULL){
		CString val;
		val.Format("%d", m_nId);
		m_ctrlID.SetWindowText(val);
		m_ctrlName.SetWindowText(m_strName);
		val.Format("%d", m_nAge);
		m_ctrlAge.SetWindowText(val);
		m_ctrlEmail.SetWindowText(m_strEmail);
	}
	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void User::ClickEditId()
{
	CKeyBoard dlg;
	dlg.CommentSet("Input user ID.", 240, 600);
	if (dlg.DoModal() == IDOK)
	{
		CString str = "";
		str.Format("%s", dlg.m_strKeyBDDisplay);
		m_ctrlID.SetCaption(str);
		m_nId = atoi(str);
	}
}


void User::ClickEditName()
{
	// TODO: Add your message handler code here
	CKeyBoard dlg;
	dlg.CommentSet("Input Name.", 240, 600);
	if (dlg.DoModal() == IDOK)
	{
		CString str = "";
		str.Format("%s", dlg.m_strKeyBDDisplay);
		m_ctrlName.SetCaption(str);
		m_strName = str;
	}
}


void User::ClickEditAge()
{
	// TODO: Add your message handler code here
	CKeyBoard dlg;
	dlg.CommentSet("Input Age.", 240, 600);
	if (dlg.DoModal() == IDOK)
	{
		CString str = "";
		str.Format("%s", dlg.m_strKeyBDDisplay);
		m_ctrlAge.SetCaption(str);
		m_nAge = atoi(str);
	}
}


void User::ClickEditEmail()
{
	// TODO: Add your message handler code here
	CKeyBoard dlg;
	dlg.CommentSet("Input Email.", 240, 600);
	if (dlg.DoModal() == IDOK)
	{
		CString str = "";
		str.Format("%s", dlg.m_strKeyBDDisplay);
		m_ctrlEmail.SetCaption(str);
		m_strEmail = str;
	}
}


void User::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}
